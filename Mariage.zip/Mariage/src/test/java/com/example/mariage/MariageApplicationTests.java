package com.example.mariage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MariageApplicationTests {

	@Test
	void contextLoads() {
	}

}
