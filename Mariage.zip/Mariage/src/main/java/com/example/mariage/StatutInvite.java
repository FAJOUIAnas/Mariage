package com.example.mariage;

public enum StatutInvite {
    TEMOIN,
    INVITE_EPOUSE,
    INVITE_EPOUX
}
